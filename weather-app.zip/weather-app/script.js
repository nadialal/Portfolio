async function getWeather(){

let city = document.getElementById("cityInput").value;

let apiKey = "660c0d76b670c03f18f4eff446cacd12";

let url = "https://api.openweathermap.org/data/2.5/weather?q=" 
+ city + 
"&appid=" + apiKey + 
"&units=metric";

try{

let response = await fetch(url);

let data = await response.json();

if(data.cod == 404){
document.getElementById("weatherResult").innerHTML = "City not found";
return;
}

let temp = data.main.temp;
let description = data.weather[0].description;

document.getElementById("weatherResult").innerHTML =
"Temperature: " + temp + "°C <br> Weather: " + description;

}catch(error){

document.getElementById("weatherResult").innerHTML =
"Error retrieving weather data";

}

}